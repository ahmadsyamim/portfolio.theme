@include('portfolio.partials.meta')
@include('portfolio.partials.header')

<main class="l-main">
    @yield('content')
</main>
<!------------------------ Body ends from here ----------------------->
